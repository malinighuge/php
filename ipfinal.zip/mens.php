<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

body {
    background-color: #f1f1f1;
    padding: 20px;
    font-family: Arial;
}

/* Center website */
.main {
    max-width: 1000px;
    margin: auto;
}

h1 {
    font-size: 50px;
    
}

.row {
    margin: 8px -16px;
}

/* Add padding BETWEEN each column */
.row,
.row > .column {
    padding: 8px;
}

/* Create four equal columns that floats next to each other */
.column {
    float: left;
    width: 25%;
}

/* Clear floats after rows */ 
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Content */
.content {
    background-color: white;
    padding: 10px;
    
}
.con:hover {
    position:relative;
    top:-25px;
    left:-35px;
    width:300px;
    height:300px;
    display:block;
    z-index:999;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 900px) {
    .column {
        width: 50%;
    }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}
.dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
/* Style the buttons */
.btn {
  border: 2px solid black ;
  border-radius: 5px;
  color: black;
  padding: 12px 16px;
  background-color: white;
  cursor: pointer;
}

.btn:hover {
  background-color: #ddd;
}

.btn.active {
  background-color: #666;
  color: white;
}
</style>
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">

<h1 style="font-family:eufm10;">SilverStone!!!</h1>
<hr>

<h2 style="font-family:eufm10;">Mens Section</h2>
<div
 class="dropdown" style="float:left;">
  <button class="dropbtn">Categories</button>
  <div class="dropdown-content" style="left:0;">
    <a class="active"  href="mens.php">Clothes</a>
    
    <a href="menfootwear.php">Footwear & Accessories</a>
    <a href="menm.php">Others</a>
  </div>
</div>
<br>
<br>

<div class="row">
  <div class="column">
    <div class="content">
    
      <img src="m9.jpeg" class="con">
      <h3>Navyblue Shirt </h3>
      <p>Product-id:m-1</p>
      <p> Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="m10.jpeg" style="width:100%">
      <h3>Plainshirt</h3>
      <p>Product-id:m-2</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>   
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="m11.jpeg"  style="width:100%">
      <h3>Skyblue Shirt<h3>
      <p>Product-id:m-3</p>
      <p>Rs 500</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>    
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="m12.jpeg"  style="width:100%">
      <h3>Rbl Shirt</h3>
      <p>Product-id:m-4</p>
      <p>Rs 550</p>
      <button class="btn"onclick="window.open('userdetail.php');return false;">BUY NOW</button>
      
    </div>
  </div>
</div>
<div class="row">
   <div class="column">
    <div class="content">
    <img src="m13.jpeg" style="width:100%">
      <h3>DJ&C T-Shirt</h3>
      <p>Product-id:m-5</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column">
    <div class="content">
    <img src="m14.jpeg"  style="width:100%">
      <h3>Breys T-Shirt</h3>
      <p>Product-id:m-6</p>
      <p>Rs 300</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column">
    <div class="content">
    <img src="m15.jpeg"  style="width:100%">
      <h3>White T-Shirt</h3>
      <p>Product-id:m-7</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column">
    <div class="content">
    <img src="m16.jpeg"  style="width:100%">
      <h3>Gray T-Shirt</h3>
      <p>Product-id:m-8</p>
      <p>Rs 300</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>



<!-- END MAIN -->
</div>

</body>
</html>