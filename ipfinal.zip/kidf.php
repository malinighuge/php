<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">

<h1 style="font-family:eufm10;">SilverStone!!!</h1>
<hr>

<h2 style="font-family:eufm10;">Kids Section</h2>
<div id="myBtnContainer">
  <button class="btn active" onclick="filterSelection('all')"> Show all</button>
  <button class="btn" onclick="filterSelection('shoes')"> Shoes</button>
  <button class="btn" onclick="filterSelection('kittoes')"> Kittoes</button>
  <button class="btn" onclick="filterSelection('boots')"> Boots</button>
  <button class="btn" onclick="filterSelection('canvas')"> Canvas</button>
</div>




<div class="row">
  <div class="column shoes">
    <div class="content">
      <img src="b14.jpeg"  style="width:100%">
      <h3>Black Shoes</h3>
      <p>Product-id:k-9</p>
      <p> ₹450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column shoes">
    <div class="content">
    <img src="b15.jpeg"  style="width:100%">
      <h3>Lavender Shoes </h3>
      <p>Product-id:k-10</p>
      <p>₹350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>   
    </div>
  </div>
  <div class="column kittoes">
    <div class="content">
    <img src="b16.jpeg"  style="width:100%">
      <h3>Blue Kittoes<h3>
      <p>Product-id:k-11</p>
      <p>Rs 250</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>    
    </div>
  </div>
  <div class="column kittoes">
    <div class="content">
    <img src="b17.jpeg"  style="width:100%">
      <h3>Pink Kittoes</h3>
      <p>Product-id:k12</p>
      <p>Rs 225</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
      
    </div>
  </div>
</div>


<div class="row">
   <div class="column canvas">
    <div class="content">
    <img src="b13.jpeg"  style="width:100%">
      <h3>Purple Canvas</h3>
      <p>Product-id:k-13</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column canvas">
    <div class="content">
    <img src="b11.jpeg" style="width:100%">
      <h3>Pink Canvas</h3>
      <p>Product-id:k-14</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column boots">
    <div class="content">
    <img src="b10.jpeg"  style="width:100%">
      <h3>Gray Boots</h3>
      <p>Product-id:k-15</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column boots">
    <div class="content">
    <img src="b12.jpeg"  style="width:100%">
      <h3>Brown Boots</h3>
      <p>Product-id:k-16</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>


<!-- END MAIN -->
</div>
<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>


</body>
</html>
