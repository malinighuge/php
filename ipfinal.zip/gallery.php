<!DOCTYPE HTML>
<HEAD>

<TITLE>
hi

</TITLE>

<link rel="stylesheet" type="text/css" href="newGAL.css">
</HEAD>

<body background="images/back.png">
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alright";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if(isset($_POST['submit']))
{
$cid=$_POST['cid'];
$quantity=$_POST['quantity'];


$query = "INSERT INTO cart (cid,quantity)values('$cid','$quantity')";

$query_run = mysqli_query($conn,$query);


}
mysqli_close($conn);
?>





  <a href="gallery.php"><button>Our products</button></a>
  <a href="loginn.php"><button>Logout</button></a>
  
  
  
 </div>

<div id='hi'>
	<h1>CLOTHES</h1>
	
	<h2>MENS SECTION</h2>
	

	<div id="Gallery">

   	 <img src="m9.jpeg" alt="Cinque Terre" >
  	<br>
	<b>  <i>1.Navyblue Shirt-MRP-450</i></b>
  	<form action="" method="post">
	PRODUCT ID:-<input name="cid">
	QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
	<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit" ></p></a>
	</form>
	</div>
	<div id="Gallery">
  	
   	 <img src="m10.jpeg" alt="Cinque Terre" >
 	 
 	 <br>
	<b>  <i>2.Plainshirt- MRP 450</i></b>
  	<form action="" method="post">
	PRODUCT ID:-<input name="cid">
	QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
	<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
	</form>
	</div><div id="Gallery">

   	 <img src="m11.jpeg" alt="Cinque Terre" >
  	
  	<br>
	<b>  <i>3.Skyblue Shirt- MRP 500</i></b>
  	<form action="" method="post">
	PRODUCT ID:-<input name="cid">
	QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
	<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
	</form>
	</div>

	<div id="Gallery">


   	 <img src="m12.jpeg" alt="Cinque Terre" >
 	 
  	<br>
	<b>  <i>4.Rbl Shirt- MRP 550</i></b>

  	<form action="" method="post">
	PRODUCT ID:-<input name="cid">
	QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
	<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
	</form>
	</div>
</div>
 <br>
 
 
 
<div id='hi'>
<br>
<br>
<br>
<br>
<br>
<h2>WOMENS SECTION</h2>
</div>

<div id="Gallery">
  <a href="a8.jpg">
    <img src="d1.jpeg"  alt="Cinque Terre" >
  </a>
  <br>
<b>  <i>Floral Pink Top MRP-350</i></b>
  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit" ></p></a>
</form>
</div>
<div id="Gallery">
  
    <img src="d2.jpeg" alt="Cinque Terre" >
  
  <br>
<b>  <i>Plain Pink Top MRP-250</i></b>
  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
</form>
</div><div id="Gallery">

    <img src="d3.jpeg" alt="Cinque Terre" >
  
  <br>
<b>  <i>FullSleeve Top- MRP 300</i></b>
  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
</form>
</div>

<div id="Gallery">


    <img src="d4.jpeg" alt="Cinque Terre" >
  
  <br>
<b>  <i>Plain White Top- MRP 225</i></b>

  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
</form>
</div>

 
</div>

<div id='hi'>
<br>
<br>
<br>
<br>
<br>
<h2>KIDS SECTION</h2>
<h3></div>

<div id="Gallery">
  <a href="a8.jpg">
    <img src="b1.jpeg"  alt="Cinque Terre" >
  </a>
  <br>
<b>  <i>Smiley Tees MRP-350</i></b>
  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit" ></p></a>
</form>
</div>
<div id="Gallery">
  
    <img src="b2.jpeg" alt="Cinque Terre" >
  
  <br>
<b>  <i>Printed Tees MRP-400</i></b>
  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
</form>
</div><div id="Gallery">
  
    <img src="b3.jpeg" alt="Cinque Terre" >
  
  <br>
<b>  <i> Checks Shirt- MRP 350</i></b>
  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
</form>
</div>

<div id="Gallery">

  
    <img src="b4.jpeg" alt="Cinque Terre" >
  
  <br>
<b>  <i> Cartoon Nightwear- MRP 500</i></b>

  <form action="" method="post">
PRODUCT ID:-<input name="cid">
QUANTITY:-&nbsp;&nbsp;&nbsp;<input name="quantity">
<p><a href="gallery.php"><input type="submit" value="Submit" name="submit" id="submit"></p></a>
</form>
</div>

 
</div>
 <button id="button" onclick="window.open('check.php');return false;">CONTINUE TO CHECKOUT </a></button>

</body>
</html>
