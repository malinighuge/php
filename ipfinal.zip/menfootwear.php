<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">

<h1>SilverStone!!!</h1>
<hr>

<h2>Mens Section</h2>
<div id="myBtnContainer">
  <button class="btn active" onclick="filterSelection('all')"> Show all</button>
  <button class="btn" onclick="filterSelection('shoes')"> Shoes</button>
  <button class="btn" onclick="filterSelection('wallet')"> Wallets</button>
  <button class="btn" onclick="filterSelection('perfume')"> Perfumes</button>
  <button class="btn" onclick="filterSelection('glare')"> Glares</button>
  
</div>




<div class="row">
  <div class="column shoes">
    <div class="content">
      <img src="m1.jpeg"  style="width:100%">
      <h3>DBrown Shoes</h3>
      <p>Product-id:m-9</p>
      <p> Rs 600</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column shoes">
    <div class="content">
    <img src="m2.jpeg"  style="width:100%">
      <h3>Bluecanvas </h3>
      <p>Product-id:m-10</p>
      <p>Rs 400</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>   
    </div>
  </div>
  <div class="column shoes">
    <div class="content">
    <img src="m3.jpeg" style="width:100%">
      <h3>BlueShoes<h3>
      <p>Product-id:m-11</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>    
    </div>
  </div>
  <div class="column shoes">
    <div class="content">
    <img src="m4.jpeg" style="width:100%">
      <h3>Adidas Shoes</h3>
      <p>Product-id:m-12</p>
      <p>Rs 650</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
      
    </div>
  </div>
</div>
<div class="row">
   <div class="column wallet">
    <div class="content">
    <img src="m5.jpeg"  style="width:100%">
      <h3>BlackWallet</h3>
      <p>Product-id:m-13</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column wallet">
    <div class="content">
    <img src="m6.jpeg"  style="width:100%">
      <h3>OcharWallet</h3>
      <p>Product-id:m-14</p>
      <p>Rs 400</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column wallet">
    <div class="content">
    <img src="m7.jpeg" style="width:100%">
      <h3>NeoBlk Wallet</h3>
      <p>Product-id:m-15</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column wallet">
    <div class="content">
    <img src="m8.jpeg"  style="width:100%">
      <h3>RGB Wallet</h3>
      <p>Product-id:m-16</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>

<div class="row">
   <div class="column glare">
    <div class="content">
    <img src="men3.jpeg" style="width:100%">
      <h3>Cross glares</h3>
      <p>Product-id:m-17</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column glare">
    <div class="content">
    <img src="men4.jpeg"  style="width:100%">
      <h3>BG glares</h3>
      <p>Product-id:m-18</p> 
      <p>Rs 500</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column perfume">
    <div class="content">
    <img src="men6.jpeg" style="width:100%">
      <h3>Napoleon perfume</h3>
      <p>Product-id:m-19</p>
      <p>Rs 650</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column perfume">
    <div class="content">
    <img src="men8.jpeg" style="width:100%">
      <h3>CK perfume</h3>
      <p>Product-id:m-20</p>
      <p>Rs 550</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>


<!-- END MAIN -->
</div>
<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>


</body>
</html>