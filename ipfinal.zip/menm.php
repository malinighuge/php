<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">

<h1 style="font-family:eufm10;">SilverStone!!!</h1>
<hr>

<h2 style="font-family:eufm10;">Men Section</h2>
<div id="myBtnContainer">
  <button class="btn active" onclick="filterSelection('all')"> Show all</button>
  
  <button class="btn" onclick="filterSelection('watch')"> Watch</button>
  <button class="btn" onclick="filterSelection('mugs')"> Mugs</button>

</div>




<div class="row">
  <div class="column watch">
    <div class="content">
      <img src="m1.jpg"  style="width:100%">
      <h3>waterproof watch</h3>
      <p>Product-id:m-21</p>
      <p> Rs 800</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column watch">
    <div class="content">
    <img src="m2.jpg"  style="width:100%">
      <h3>MI band</h3>
      <p>Product-id:m-22</p>
      <p>Rs 1000</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>   
    </div>
  </div>
  <div class="column watch">
    <div class="content">
    <img src="m3.jpg" style="width:100%">
      <h3>Bluetooth smart watch<h3>
      <p>Product-id:m-23</p>
      <p>Rs 2000</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>    
    </div>
  </div>
  <div class="column watch">
    <div class="content">
    <img src="m4.jpg"  style="width:100%">
      <h3>Bluetooth smart watch</h3>
      <p>Product-id:m-24</p>
      <p>Rs 700</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
      
    </div>
  </div>
</div>


<div class="row">
   <div class="column mugs">
    <div class="content">
    <img src="m5.jpg"  style="width:100%">
      <h3>white mug</h3>
      <p>Product-id:m-25</p>
      <p>Rs 250</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column mugs">
    <div class="content">
    <img src="m6.jpg"  style="width:100%">
      <h3>Heart mugs</h3>
      <p>Product-id:m-26</p>
      <p>Rs 550</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column mugs">
    <div class="content">
    <img src="m7.jpg" style="width:100%">
      <h3>paladone mug</h3>
      <p>Product-id:m-27</p>
      <p>Rs 250</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column mugs">
    <div class="content">
    <img src="m8.jpg"  style="width:100%">
      <h3>Glitter coffee mug</h3>
      <p>Product-id:m-28</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>


<!-- END MAIN -->
</div>
<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>


</body>
</html>
