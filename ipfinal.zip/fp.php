<?php
session_start();
if(!isset($_SESSION['user'])){
header('location:fp.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
body {
    background-image: url("i.jpg");
    background-repeat: no-repeat;
    background-color: none;
    background-size: cover;
    width: 100%;
}
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: sandybrown;
}

li {
    float: left;
}

li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover {
    background-color: bisque;
}
li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}

li a:hover, .categories:hover .dropbtn {
    background-color:#ffc8b3;
}

li.Categories {
    display: inline-block;
}

.content {
    display: none;
    position: absolute;
    background-color:#f2f2f2;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}

.content a:hover {background-color:	#ffb3b3;}

.Categories:hover .content {
    display: block;
}
header{
background:sandybrown;
color: white;
padding-top: : 8px ;
padding-right: 0px;
padding-bottom: 6px ;
padding-left:40px;
height: 41px;
}
header h1{
display: inline;
font-family:Arial, Helvetica, sans-serif ;
font-size:45px ;
font-weight: 400;
float: left;
margin-top:0 ;
margin-right: 0;
padding:8px 15px 5px 0px ;

}

</style>
</head>
<body>
<header>
		<nav>
			<h1 style="font-family:eufm10;"> SilverStone Gift Shop!!!</h1>

<ul>
  <li><a class="active" href="fp.php">Home</a></li>
  
  <li class="Categories">
    <a href="javascript:void(0)" class="dropbtn">Categories</a>
    <div class="content">
      <a href="women.php">Womens</a>
      <a href="mens.php">Men</a>
      <a href="kid.php">Kids</a>
    </div>
  </li>
  <li><a class="active" href="gallery.php">Gallery</a></li>
  <li><a class="active" href="about.html">About Us</a></li>
  <li><a class="active" href="feedback.php">Feedback</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</nav>
</header>
<h1 style="font-family:eufm10; color:white;">Welcome <?php echo$_SESSION['user']; ?></h1>
	
</body>
		
		
