<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">

<h1 style="font-family:eufm10;">SilverStone!!!</h1>
<hr>

<h2 style="font-family:eufm10;">Kids Section</h2>
<div id="myBtnContainer">
  <button class="btn active" onclick="filterSelection('all')"> Show all</button>
  
  <button class="btn" onclick="filterSelection('bicycle')"> Bicycle</button>
  <button class="btn" onclick="filterSelection('toys')"> Toys</button>
  <button class="btn" onclick="filterSelection('studytable')"> Studytable</button>
</div>




<div class="row">
  <div class="column studytable">
    <div class="content">
      <img src="kid9.jpeg"  style="width:100%">
      <h3>Blue St</h3>
      <p>Product-id:k-17</p>
      <p> Rs 890</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column studytable">
    <div class="content">
    <img src="kid5.jpeg" style="width:100%">
      <h3>Green st</h3>
      <p>Product-id:k-18</p>
      <p>Rs 850</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>   
    </div>
  </div>
  <div class="column bicycle">
    <div class="content">
    <img src="kid1.jpeg"  style="width:100%">
      <h3>Red bicycle<h3>
      <p>Product-id:k-19</p>
      <p>Rs 1700</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>    
    </div>
  </div>
  <div class="column bicycle">
    <div class="content">
    <img src="kid2.jpeg" style="width:100%">
      <h3>Pink bicycle</h3>
      <p>Product-id:k-20</p>
      <p>Rs 1500</p>
      
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
      
    </div>
  </div>
</div>


<div class="row">
   <div class="column toys">
    <div class="content">
    <img src="kid4.jpeg"  style="width:100%">
      <h3>Blocks</h3>
      <p>Product-id:k-21</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column toys">
    <div class="content">
    <img src="kid6.jpeg"  style="width:100%">
      <h3>GT toy</h3>
      <p>Product-id:23</p>
      <p>Rs 150</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column toys">
    <div class="content">
    <img src="kid7.jpeg" style="width:100%">
      <h3>Barbie</h3>
      <p>Product-id:24</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column toys">
    <div class="content">
    <img src="kid8.jpeg"  style="width:100%">
      <h3>Soft toy</h3>
      <p>Product-id:25</p>
      <p>Rs 250</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>


<!-- END MAIN -->
</div>
<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>


</body>
</html>
