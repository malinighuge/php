<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

body {
    background-color: #f1f1f1;
    padding: 20px;
    font-family: Arial;
}

/* Center website */
.main {
    max-width: 1000px;
    margin: auto;
}

h1 {
    font-size: 50px;
    word-break: break-all;
}

.row {
    margin: 8px -16px;
}

/* Add padding BETWEEN each column */
.row,
.row > .column {
    padding: 8px;
}

/* Create four equal columns that floats next to each other */
.column {
    float: left;
    width: 25%;
}

/* Clear floats after rows */ 
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Content */
.content {
    background-color: white;
    padding: 10px;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 900px) {
    .column {
        width: 50%;
    }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}
.dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
/* Style the buttons */
.btn {
  border: 2px solid black ;
  border-radius: 5px;
  color: black;
  padding: 12px 16px;
  background-color: white;
  cursor: pointer;
}

.btn:hover {
  background-color: #ddd;
}

.btn.active {
  background-color: #666;
  color: white;
}
</style>
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">

<h1 style="font-family:eufm10;> SilverStone!!! </h1>
<hr>

<h2 style="font-family:eufm10;">Kids Section</h2>
<div class="dropdown" style="float:left;">
  <button class="dropbtn">Categories</button>
  <div class="dropdown-content" style="left:0;">
    <a class="active"  href="kid.php">Clothes</a>
    
    <a href="kidf.php">Footwear</a>
    <a href="kidt.php">Games</a>
    
  </div>
</div>
<br>
<br>


<div class="row">
  <div class="column">
    <div class="content">
      <img src="b1.jpeg"  style="width:100%">
      <h3>Smiley Tees</h3>
      <p>Product-id:k-1</p>
      <p> Rs 300</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="b2.jpeg"  style="width:100%">
      <h3>Printed Tees </h3>
      <p>Product-id:k-2</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>   
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="b3.jpeg" style="width:100%">
      <h3>Checks Shirt<h3>
      <p>Product-id:k-3</p>
      <p>Rs 350</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>    
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="b4.jpeg"  style="width:100%">
      <h3>Cartoon Nightwear</h3>
      <p>Product-id:k-4</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
      
    </div>
  </div>
</div>
<div class="row">
   <div class="column">
    <div class="content">
    <img src="b5.jpeg"  style="width:100%">
      <h3>Denim Frock</h3>
      <p>Product-id:k-5</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column">
    <div class="content">
    <img src="b9.jpeg"  style="width:100%">
      <h3>YB Full set</h3>
      <p>Product-id:k-6</p>
      <p>Rs 500</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column">
    <div class="content">
    <img src="b7.jpeg"  style="width:100%">
      <h3>Floral Frock</h3>
      <p>Product-id:k-7</p>
      <p>Rs 450</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column">
    <div class="content">
    <img src="b8.jpeg" style="width:100%">
      <h3>Zara Black Top</h3>
      <p>Product-id:k-8</p>
      <p>Rs 250</p>
      <button class="btn" onclick="window.open('userdetail.php');return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>



<!-- END MAIN -->
</div>

</body>
</html>