<html>
<head>

<title>
hi

</title>

<link rel="stylesheet" type="text/css" href="check.css" >
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alright";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if(isset($_POST['submit']))
{
$sql = "DELETE FROM cart";

$result = mysqli_query($conn, $sql);
}


mysqli_close($conn);

?>

<div class="main_wrapper">

<div class="menubar">
<div class="tab">

  
  <a href="gallery.php"><button>gallery</button></a>
 
 </div>

    </div>
  </div>

  <div class="col-25">
    <div class="container">
      <h4>Cart 
        <span class="price" style="color:black">
          <i class="fa fa-shopping-cart"></i> 
          <b>
		        <?php include 'test2.php';?>

		  </b>
        </span>
      </h4>
      <?php include 'test1.php';?>
  <form action="" method="post">

<input type="submit" value="clear cart" name="submit" >
</form>
  </div>
  </div>

<a href="userdetail.php"><button>PAY</button></a>
</html>