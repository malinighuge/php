
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="my.css">
</head>
<body>

<!-- MAIN (Center website) -->
<div class="main">

<h1 style="font-family:eufm10;">SilverStone!!!</h1>
<hr>

<h2 style="font-family:eufm10;">Kids Section</h2>
<div id="myBtnContainer">
  <button class="btn active" onclick="filterSelection('all')"> Show all</button>
  
  <button class="btn" onclick="filterSelection('Cosmetics')"> Cosmetics</button>
  <button class="btn" onclick="filterSelection('jewellery')"> jewellery</button>
  
</div>



<div class="row">
  <div class="column jewellery">
    <div class="content">
      <img src="a.jpg"  style="width:100%">
      <h3>warton goldsmith</h3>
      <p>Product-id:w-21</p>
      <p>Rs 350</p>
    <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column jewellery">
    <div class="content">
    <img src="a1.jpg"  style="width:100%">
      <h3>silver gold necklaces </h3>
      <p>Product-id:w-22</p>
      <p>Rs.250</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column jewellery">
    <div class="content">
    <img src="a2.jpg"  style="width:100%">
      <h3>Diamond ring</h3>
      <p>Product-id:w-23</p>
      <p>Rs 550</p>
   <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column jewellery">
    <div class="content">
    <img src="a3.jpg"  style="width:100%">
      <h3>Diamond bracelets</h3>
      <p>Product-id:w-24</p>
      <p>Rs 625</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
      
    </div>
  </div>
</div>


<div class="row">
   <div class="column Cosmetics">
    <div class="content">
    <img src="a4.jpg"  style="width:100%">
      <h3>Nail polish</h3>
      <p>Product-id:w-25</p>
      <p>Rs 150</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column Cosmetics">
    <div class="content">
    <img src="a5.jpg"  style="width:100%">
      <h3>Focallure foundation</h3>
      <p>Product-id:w-26</p>
      <p>Rs 450</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column Cosmetics">
    <div class="content">
    <img src="a6.jpg"  style="width:100%">
      <h3>liner</h3>
      <p>Product-id:w-27</p>
      <p>Rs 150</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column Cosmetics">
    <div class="content">
    <img src="a7.jpg"  style="width:100%">
      <h3>Bora custom lipstick</h3>
      <p>Product-id:w-28</p>
      <p>Rs 550</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>


<!-- END MAIN -->
</div>
<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>


</body>
</html>
