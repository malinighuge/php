<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title></title>
 
</head>
<style>
body{
	background-image: url(t.jpg);
	background-image: no repeat;
	background-size: 100% ;
}
#wrapper {
  width: 30%;
  margin: 50px auto;
  padding: 40px;
  background:#CCCCFF;
}
form {
  margin: 30px auto;
}
.textInput {
  border: none;
  height: 28px;
  margin: 2px;
  border: 1px solid;
  font-size: 1.2em;
  padding: 5px;
  width: 95%;
}
.textInput:focus {
  outline: none;
}
.btn {
  width: 98.6%;
  border: none;
  margin-top: 5px;
  color: white;
  background-color: #CC3366;
  border-radius: 5px;
  padding: 12px;
}
h1{
text-align: center;
color:#990099;
font-family: Georgia, serif	;
}
p{
text-align:center;}
</style>
<body>
 <h1>User details</h1>
  <div id="wrapper">
   <form id="userdetail" action="ud.php"method="post">
   
   	<div id="name">
   	  <label>Fullname</label> <br>
   	  <input type="text" name="Fullname" class="textInput">
   	  <div id="name_error"></div>
   	</div>
   	<div id="email">
   	  <label>Email</label> <br>
   	  <input type="email" name="Email" class="textInput">
   	  <div id="email_error"></div>
   	</div>
   	<div id="Address">
   	  <label>Address</label> <br>
   	  <input type="text" name="Address" class="textInput">
   	</div>
   	<div id="city">
   	   <label>city</label> <br>
                 
   	   <input type="text" name="city" class="textInput" onkeyup="showHint(this.value)">
                   Suggestions: <span id="txtHint"></span>
   	   <div id="password_error"></div>
   	</div>
   	<div id="state">
   	   <label>State</label> <br>
   	   <input type="text" name="State" class="textInput">
   	   
   	</div>
   	<div id="mobileno">
   	   <label>MobileNumber</label> 
   	   <input type="text" name="MobileNumber" class="textInput">
   	   
   	</div>
   	<div id="productid">
   	   <label>product_id</label> 
   	   <input type="text" name="product_id" class="textInput">
   	   
   	</div>
   	<div>
   	<button class="btn" type="submit" value="Submit" onclick="window.open('out.php');return false;">>SUBMIT</button>
   	</div>
   	 
    </div>
   </form>
  </div>
<script>
function showHint(str) {
  var xhttp;
  if (str.length == 0) { 
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      document.getElementById("txtHint").innerHTML = this.responseText;
    }
  };
  xhttp.open("GET", "gethint.php?q="+str, true);
  xhttp.send();   
}
</script>
</body>
</html>