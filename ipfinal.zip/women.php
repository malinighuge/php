<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
    box-sizing: border-box;
}

body {
    background-color: #f1f1f1;
    padding: 20px;
    font-family: Arial;
}

/* Center website */
.main {
    max-width: 1000px;
    margin: auto;
}

h1 {
    font-size: 50px;
    
}

.row {
    margin: 8px -16px;
}

/* Add padding BETWEEN each column */
.row,
.row > .column {
    padding: 8px;
}

/* Create four equal columns that floats next to each other */
.column {
    float: left;
    width: 25%;
}

/* Clear floats after rows */ 
.row:after {
    content: "";
    display: table;
    clear: both;
}

/* Content */
.content {
    background-color: white;
    padding: 10px;
}

/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 900px) {
    .column {
        width: 50%;
    }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
    .column {
        width: 100%;
    }
}
.dropbtn {
    background-color: #4CAF50;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
    display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    right: 0;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    z-index: 1;
}

.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1;}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
}
.show {
  display: block;
}

/* Style the buttons */
.btn {
  border: 2px solid black ;
  border-radius: 5px;
  color: black;
  padding: 12px 16px;
  background-color: white;
  cursor: pointer;
}

.btn:hover {
  background-color: #ddd;
}

.btn.active {
  background-color: #666;
  color: white;
}
</style>
</head>
<body>


<div class="main">

<h1 style="font-family:eufm10;">SilverStone!!!</h1>
<hr>

<h2 style="font-family:eufm10;">Womens Section</h2>
<div class="dropdown" style="float:left;">
  <button class="dropbtn">Categories</button>
  <div class="dropdown-content" style="left:0;">
    <a class="active"  href="women.php">Clothes</a>
    
    <a href="womenfootwear.php">Footwear</a>
    <a href="womenj.php">Accessories</a>
  </div>
</div>
<br>
<br>

<div class="row">
  <div class="column top">
    <div class="content">
      <img src="d1.jpeg"  style="width:100%">
      <h3>Floral Pink Top</h3>
      <p>Product-id:w-1</p>
      <p> Rs 250</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
  <div class="column top">
    <div class="content">
    <img src="d2.jpeg"  style="width:100%">
      <h3>Plain Pink Top </h3>
      <p>Product-id:w-2</p>
      <p>Rs 250</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>   
    </div>
  </div>
  <div class="column top">
    <div class="content">
    <img src="d3.jpeg" style="width:100%">
      <h3>FullSleeve Top<h3>
      <p>Product-id:w-3</p>
      <p>Rs 250</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>    
    </div>
  </div>
  <div class="column top">
    <div class="content">
    <img src="d4.jpeg" style="width:100%">
      <h3>Plain White Top</h3>
      <p>Product-id:w-4</p>
      <p>Rs 225</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
      
    </div>
  </div>
</div>
<div class="row">
   <div class="column kurti">
    <div class="content">
    <img src="d7.jpeg"  style="width:100%">
      <h3>Yellow Floral Kurti</h3>
      <p>Product-id:w-5</p>
      <p>Rs 450</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column kurti">
    <div class="content">
    <img src="d8.jpeg"  style="width:100%">
      <h3>GB Kurti</h3>
      <p>Product-id:w-6</p>
      <p>Rs 500</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column kurti">
    <div class="content">
    <img src="d9.jpeg" style="width:100%">
      <h3>Zara's Black Kurti</h3>
      <p>Product-id:w-7</p>
      <p>Rs 450</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column kurti">
    <div class="content">
    <img src="d10.jpeg"  style="width:100%">
      <h3>Blue Applecut Kurti</h3>
      <p>Product-id:w-8</p>
      <p>Rs 300</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>

<div class="row">
   <div class="column top">
    <div class="content">
    <img src="d5.jpeg"  style="width:100%">
      <h3>Sidecut Black Top</h3>
      <p>Product-id:w-9</p>
      <p>Rs 250</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column top">
    <div class="content">
    <img src="d6.jpeg"  style="width:100%">
      <h3>Stripes Top</h3>
      <p>Product-id:w-10</p>
      <p>Rs 250</p>
      <button class="btn"onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column top">
    <div class="content">
    <img src="d11.jpeg" style="width:100%">
      <h3>Shein's White Top</h3>
      <p>Product-id:w-11</p>
      <p>Rs 350</p>
      <button class="btn"onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
   <div class="column top">
    <div class="content">
    <img src="d12.jpeg" style="width:100%">
      <h3>Akriti's Grey Top</h3>
      <p>Product-id:w-12</p>
      <p>Rs 350</p>
      <button class="btn" onclick=" window.open('userdetail.php'); return false;">BUY NOW</button>
    </div>
  </div>
<!-- END GRID -->
</div>


<!-- END MAIN -->
</div>
<script>
filterSelection("all")
function filterSelection(c) {
  var x, i;
  x = document.getElementsByClassName("column");
  if (c == "all") c = "";
  for (i = 0; i < x.length; i++) {
    w3RemoveClass(x[i], "show");
    if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
  }
}

function w3AddClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
  }
}

function w3RemoveClass(element, name) {
  var i, arr1, arr2;
  arr1 = element.className.split(" ");
  arr2 = name.split(" ");
  for (i = 0; i < arr2.length; i++) {
    while (arr1.indexOf(arr2[i]) > -1) {
      arr1.splice(arr1.indexOf(arr2[i]), 1);     
    }
  }
  element.className = arr1.join(" ");
}


// Add active class to the current button (highlight it)
var btnContainer = document.getElementById("myBtnContainer");
var btns = btnContainer.getElementsByClassName("btn");
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function(){
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
</script>


</body>
</html>
