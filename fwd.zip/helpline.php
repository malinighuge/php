<!DOCTYPE HTML>
<HEAD>

<TITLE>
hi

</TITLE>

<link rel="stylesheet" type="text/css" href="../style/shelp.css" />
</HEAD>

<body>
<div class="main_wrapper">

<div class="header_wrapper">
 <img src="../images/logo.png" alt="logo">

</div>
<div class="content_wrapper">

<div class="menubar">
<div class="menubar">
<div class="tab">
<a href="slider1.php"><button>Home</button></a>
  <a href="gallery.php"><button>Our products</button></a>
   <a href="helpline.php"><button>Farmer Helpline</button></a>
  <a href="About_us.php"><button>about</button></a>
  <a href="contact1.php"><button>contact</button></a>
  <button class="tablinks" onclick="openLogout(event, 'Logout')">Logout</button>
 </div>
</div>



 </div>
</div>


<div id="content_area"> 

 <img src="../images/lol.png" alt="Italian Trulli">

<p>
<font size="5 " face="Times New Roman
Georgia" color="black"><i>Kissan Call Center :: 1800-180-1551 (from any Landline or Mobile) / 1551 (from BSNL Landline)</i></font></p>
<div style="background-color:lightblue">
<p><font size="3" face="Times New Roman
Georgia" color="black">
If you are a farmer, Farm Aid is here for you!

We have more than 30 years of experience working with farmers – whether youre looking to expand your farm or youre in need of emergency resources. When you contact Farm Aid, our goal is to connect you with helpful services, resources and opportunities specific to your individual needs. Our Farmer Resource Network offers many ways for you to connect.
Connect with An Organization

</p></font>
 
</div> 
 
Contacts
	Kisan Call Centers (India - Level I)
	Nodal Officers (India - Level III)
<img src="../images/qwe.gif" alt="Italian Trulli">

<div style="background-color:lightblue">
<p><i><font size="3" face="Times New Roman
Georgia" color="black"><b>If you need to talk to someone directly, we are here to listen. You can call our farmer hotline at 1-800-FARM-AID (1-800-327-6243). Joe and other Farm Aid staff answer the hotline Monday through Friday from 9:00 a.m. to 5:00 p.m. eastern  time.
Become A Farm Advocate

If you are interested in helping other farmers yourself, check out our Farm Advocate Link to connect with a community of professionals working one-on-one with farmers to address their needs.
</p></font>
</b>
 
</div>
<img src="../images/giphy.gif" alt="Italian Trulli">

  	

<h1>
CREATING HAPPY FARMERS !!!!! </h1>
</body>
</html>
