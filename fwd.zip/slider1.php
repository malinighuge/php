<!DOCTYPE html>
<html>
<title>HOME</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="slider2.css">
<link rel="stylesheet" href="style1.css">

<style>
.mySlides {display:none;}
</style>
<body>
<img src="logo.png" class="logo1">
<h2 class="agri1">AGRI TECH</h2>
<div class="menubar">
<div class="tab">
<a href="slider1.php"><button>Home</button></a>
  <a href="gallery.php"><button>Our products</button></a>
   <a href="helpline.php"><button>Farmer Helpline</button></a>
  <a href="About_us.php"><button>about</button></a>
  <a href="contact1.php"><button>contact</button></a>
  <button class="tablinks" onclick="openLogout(event, 'Logout')">Logout</button>
 </div>
</div>

<div class="w3-content w3-display-container">
  <img class="mySlides" src="https://images.pexels.com/photos/162637/watering-watering-can-man-vietnam-162637.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260" style="width:100%">
  <img class="mySlides" src="https://images.pexels.com/photos/164504/pexels-photo-164504.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260" style="width:100%">
  <img class="mySlides" src="https://images.pexels.com/photos/196643/pexels-photo-196643.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260" style="width:100%">
  <img class="mySlides" src="https://images.pexels.com/photos/1171521/pexels-photo-1171521.jpeg?auto-napa-vineyard-39511.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260" style="width:100%">
  <button class="w3-button w3-black w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
  <button class="w3-button w3-black w3-display-right" onclick="plusDivs(1)">&#10095;</button>
</div>

<script>
var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}
</script>

</body>
</html
}	font-weight: bold;>